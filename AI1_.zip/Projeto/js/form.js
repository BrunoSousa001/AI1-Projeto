'use strict';


class Form extends React.Component {
  constructor(props) {
      super(props);
      this.state = {value:'',};

      this.changeFunc= this.changeFunc.bind(this);
      this.submitFunc= this.submitFunc.bind(this);
  }

  changeFunc(event) {
      this.setState({value: event.target.value});
  }

  submitFunc(event) {
      event.preventDefault();
      alert('Pedido de orçamento efetuado com sucesso. Por favor aguarde resposta por email ou telefone.')
      var name = document.getElementById("Name").value;
      var email = document.getElementById("Email").value;
      var phone = document.getElementById("Tel").value;
      var message = document.getElementById("Message").value;
      const storage = window.localStorage;
      storage.setItem("name", name);
      storage.setItem("email", email);
      storage.setItem("telefone", phone);
      storage.setItem("message", message);
      document.getElementById("Name").value = '';
      document.getElementById("Email").value = '';
      document.getElementById("Tel").value = '';
      document.getElementById("Message").value = '';
  }

  render() {
      return React.createElement("div",{className: "container-form"},
      React.createElement("form", { onSubmit: this.submitFunc },
          React.createElement("label", null, "Name"),
          React.createElement("input", {
              type: "text",
              required: "required",
              id: "Name",
              onChange: this.changeFunc,
          }),
          React.createElement("label", null, "Email"),
          React.createElement("input", {
              type: "email",
              required: "required",
              id: "Email",
              onChange: this.changeFunc,
          }),
          React.createElement("label", null, "Telefone"),
          React.createElement("input", {
              type: "tel",
              required: "required",
              id: "Tel",
              onChange: this.changeFunc,
          }),
          React.createElement("label", null, "Mensagem"),
          React.createElement("textarea", {
              required: "required",
              id: "Message",
              onChange: this.changeFunc,
          }),
          React.createElement("input", {
              className: "btn",
              type: "submit",
              value: "Send",
          })
      )
      );
  }
}

const form = React.createElement(Form)
ReactDOM.render(form, document.body);