const btnMobile = document.getElementById('btn-mobile');

function toggleMenu(event) {
 /* se for mobile  apenas actva o envento touch*/  if (event.type === 'touchstart') event.preventDefault();
  const nav = document.getElementById('nav');
  nav.classList.toggle('active');
  const active = nav.classList.contains('active');
  event.currentTarget.setAttribute('aria-expanded', active);

  const header= document.getElementById('header');
  header.classList.toggle('activeheader');
  const activeheader=header.classList.contains('activeheader');
  if (active) {
    event.currentTarget.setAttribute('aria-label', 'Fechar Menu');
  } else {
    event.currentTarget.setAttribute('aria-label', 'Abrir Menu');
  }
}

btnMobile.addEventListener('click', toggleMenu);
btnMobile.addEventListener('touchstart', toggleMenu);



